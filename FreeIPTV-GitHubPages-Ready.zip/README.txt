FREE IPTV HUB — iPhone-ready PWA

This is a Progressive Web App. It can be installed on iPhone from Safari:
1. Put this folder on a web host (HTTPS is recommended).
2. Open index.html through that hosted URL in Safari.
3. Tap Share -> Add to Home Screen -> Add.

The app contains only official/free service URLs and does not include pirated
premium-channel streams. Direct playback works only for compatible direct
media URLs (for example, an accessible HLS .m3u8 URL). Website URLs open in
the embedded browser/fallback or in the official site.

For a native App Store app, the project would need to be wrapped/implemented
in Xcode and signed with an Apple developer account.
