# Free IPTV Hub — GitHub Pages

## Publish
1. Create a GitHub repository, e.g. `free-iptv`.
2. Upload all files/folders from this package to the repository.
3. Make sure the branch is named `main`.
4. Go to **Settings → Pages**.
5. Under **Build and deployment**, select **GitHub Actions**.
6. Push/commit the files.
7. Open **Actions** and wait for `Deploy Free IPTV Hub to GitHub Pages` to finish.
8. Your HTTPS site will be:
   `https://YOUR-USERNAME.github.io/free-iptv/`

GitHub Pages provides HTTPS automatically.

## iPhone
Open the HTTPS URL in Safari → Share → Add to Home Screen.

## Important
The app lists official/free service URLs. It does not contain unauthorized premium streams.
